---
title: Crypto Exchange API
keywords: API swagger crypto exchange
summary: "​Several actions are available to enable buying crypto currencies. Expected sequence of actions is displayed on following diagram:"
sidebar: mydoc_sidebar
permalink: mydoc_crypto_exchange_api
layout: swagger
---
​
<div id="swagger-ui"></div>